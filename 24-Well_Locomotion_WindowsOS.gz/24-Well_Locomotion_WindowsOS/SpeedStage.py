import os, sys, string, math, openpyxl, shutil, csv
import numpy as np
import pandas as pd

#input file name and sample numbers
name1=sys.argv[1]
name2=sys.argv[2]
fullname=name1.split(".")
listS0=[]
listS1=[]
listS2=[]
listS3=[]

for x in range(int(name2)+1):
	if x == 0:
		continue
	if x < 10:
		strg=str('0'+str(x))
	if x>9:
		strg=str(x)
	df = pd.read_csv(fullname[0]+'/Velocity/v0'+strg+'.csv')

	s0=0
	s1=0
	s2=0
	s3=0
	totalrow=len(df)
	velocity=df['mm/s']
	
	#velocity categories: 0<=Velocity<8, 8<=Velocity<16, 16<=Velocity
	for i in range(totalrow):
		if velocity[i]==0:
			s0+=1
		if velocity[i]<=8 and velocity[i]>0:
			s1+=1
		if velocity[i]>8 and velocity[i]<=16:
			s2+=1
		if velocity[i]>16:
			s3+=1

	listS0.append(s0)
	listS1.append(s1)
	listS2.append(s2)
	listS3.append(s3)

data={}
data[0]=listS0
data[1]=listS1
data[2]=listS2
data[3]=listS3

v_category = pd.DataFrame(data)
v_category.to_csv(fullname[0]+'/Velocity/V_category.csv', index = False, header=['No Speed','Low','Intermediate','High'])

#TotalDistance Calculation
list=[]
for x in range(int(name2)+1):
	if x == 0:
		continue
	if x < 10:
		strg=str('0'+str(x))
	if x>9:
		strg=str(x)
	df = pd.read_csv(fullname[0]+'/RawData/0'+strg+'.csv')
	
	sum=0
	totalrow=len(df)
	distance=df['distance']
	xpix=df['Xpix']
	ypix=df['Ypix']
	
	for i in range(1, totalrow):
		if (xpix[i]-xpix[i-1])**2>4 or (ypix[i]-ypix[i-1])**2>4:
			sum+=distance[i]
	list.append(sum)

totaldistance={}
totaldistance[0]=list
total = pd.DataFrame(totaldistance)
total.to_csv(fullname[0]+'/Velocity/TotalDistance.csv', index = False, header=['mm'])

