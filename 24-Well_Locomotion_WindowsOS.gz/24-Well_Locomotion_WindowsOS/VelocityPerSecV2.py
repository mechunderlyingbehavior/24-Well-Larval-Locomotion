import os, sys, string, math, openpyxl, shutil, csv
import numpy as np
import pandas as pd

#input file name and sample numbers
name1=sys.argv[1]
name2=sys.argv[2]

#create new diretory for velocity csv files
fullname=name1.split(".")
velocity = {}
if os.path.exists(fullname[0]+'/Velocity/'):
	shutil.rmtree(fullname[0]+'/Velocity/')
os.makedirs(fullname[0]+'/Velocity/')

for w in range(int(name2)+1):
	if w==0:
		continue
	if w<10:
		strg=str('0'+str(w))
	if w>9:
		strg=str(w)
		
	df = pd.read_csv(fullname[0]+'/RawData/0'+strg+'.csv')

	distance=df['distance']
	totalrow=len(df)
	xpix=df['Xpix']
	ypix=df['Ypix']
	time=df['Timestamp']
	timestart=int(time[0])
	timeflow=[]
	timeflow.append(time[0])

	i=0
	n=0
	totalsec=0
	list={}
	velocity={}
	
	#timestamps per 1 second
	while timestart < int(time[totalrow-1]):
		timestart=timestart+1000
		timeflow.append(timestart)
		i+=1

	for x in range(0,len(timeflow)-1):
		nlist=[]
		while n < totalrow:
			if time[n]<=timeflow[x+1] and time[n]>=timeflow[x]:
				nlist.append(n)
				n+=1
			else:
				x+=1
				nlist=[]
				continue
			list[x]=nlist
		
	#pix difference > 2
	for x in list.keys():
		sum=0
		for m in list[x]:
			if m>0 and distance[m]<>0:
				if (float(xpix[m])-float(xpix[m-1]))**2>4 or (float(ypix[m])-float(ypix[m-1]))**2>4:
					try:
						dtime=float(time[max(list[x])]-time[max(list[x-1])])
						
					except:
						dtime=float(time[max(list[x])]-time[min(list[x])])
					
					sum+=float(distance[m]/dtime)*1000
		velocity[x]= sum

	vps = pd.DataFrame(velocity,index=['mm/s'])
	vps=vps.T
	vps.to_csv(fullname[0]+'/Velocity/v0'+strg+'.csv',float_format= '%.4f')
			
	
