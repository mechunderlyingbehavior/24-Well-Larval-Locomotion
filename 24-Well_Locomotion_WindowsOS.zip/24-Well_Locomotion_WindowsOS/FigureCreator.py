#This python code was written by Li Hankun @ 17/12/2017
import pandas as pd
import matplotlib.pyplot as plt
from pylab import show
import numpy as np
import os, sys, string, math, openpyxl, shutil, csv

#input file name and sample numbers
name1=sys.argv[1]
name2=sys.argv[2]
fullname=name1.split(".")

#create new folder of different tdms files
#if the folder already exists, remove all subdirectories and write again
if os.path.exists(fullname[0]+'/Figures/'):
	shutil.rmtree(fullname[0]+'/Figures/')
os.makedirs(fullname[0]+'/Figures/')

v_category = pd.read_csv(fullname[0]+'/Velocity/V_category.csv')

s0=v_category['No Speed']
s1=v_category['Low']
s2=v_category['Intermediate']
s3=v_category['High']

for n in range(len(v_category)):
	sum=s0[n]+s1[n]+s2[n]+s3[n]
	if sum==0:
		continue
	else:
		s0[n]=float(s0[n])/float(sum)*10000
		s1[n]=float(s1[n])/float(sum)*10000
		s2[n]=float(s2[n])/float(sum)*10000
		s3[n]=float(s3[n])/float(sum)*10000

v_category.plot(kind='bar',stacked=True,color=['#6495ED','#009900','#CC6600','#FF0000'])
plt.xticks(range(-1,int(name2)+1))
plt.ylabel('%')
plt.savefig(fullname[0]+'/Figures/V_category.png')
plt.clf()

list=[]
for x in range(int(name2)+1):
	if x == 0:
		continue
	if x < 10:
		strg=str('0'+str(x))
	if x>9:
		strg=str(x)
	df = pd.read_csv(fullname[0]+'/RawData/0'+strg+'.csv')

	sum=0
	totalrow=len(df)
	distance=df['distance']
	xpix=df['Xpix']
	ypix=df['Ypix']
	
	for i in range(1, totalrow):
		if (xpix[i]-xpix[i-1])**2>4 or (ypix[i]-ypix[i-1])**2>4:
			sum+=distance[i]
	list.append(sum)

x_pos=np.arange(1,int(name2)+1)
plt.bar(x_pos,list)
plt.xticks(range(int(name2)+1))
plt.ylabel('mm')
plt.savefig(fullname[0]+'/Figures/TotalDistance.png')
plt.clf()

pause=[]
pausenumber=[]	
for x in range(int(name2)+1):
	if x == 0:
		continue
	if x < 10:
		strg=str('0'+str(x))
	if x>9:
		strg=str(x)
	df = pd.read_csv(fullname[0]+'/Pause/pv0'+strg+'.csv')
	
	add=0
	totalrow=len(df)
	pausetime=df['Pause duration']
	pausenumber.append(totalrow)
	for i in range(totalrow):
		add+=pausetime[i]
	pause.append(add)

x_pos=np.arange(1,int(name2)+1)
plt.bar(x_pos,pause)
plt.xticks(range(int(name2)+1))
plt.ylabel('sec')
plt.savefig(fullname[0]+'/Figures/Pausetime.png')
plt.clf()

x_pos=np.arange(1,int(name2)+1)
plt.bar(x_pos,pausenumber)
plt.xticks(range(int(name2)+1))
plt.ylabel('times')
plt.savefig(fullname[0]+'/Figures/Pausenumber.png')
plt.clf()

plt.figure(figsize=(5,5))
for x in range(int(name2)+1):
	if x == 0:
		continue
	if x < 10:
		strg=str('0'+str(x))
	if x>9:
		strg=str(x)
	df = pd.read_csv(fullname[0]+'/RawData/0'+strg+'.csv')
	af = pd.read_csv(fullname[0]+'/Velocity/v0'+strg+'.csv')

	speed=af['mm/s']
	totalsec=len(speed)

	totalrow=len(df)
	xpix=df['Xpix']
	ypix=df['Ypix']
	time=df['Timestamp']

	xlist0=[]
	ylist0=[]
	xlist1=[]
	ylist1=[]
	xlist2=[]
	ylist2=[]
	xlist3=[]
	ylist3=[]

	i=0
	m=0

	for i in range(len(speed)):
		if speed[i]>16:
			for m in range(totalrow):
				if time[m] > time[0]+1000*i and time[m] < time[0]+1000*(i+1):
					xlist3.append(xpix[m])
					ylist3.append(ypix[m])
		elif speed[i]>8 and speed[i]<=16:
			for m in range(totalrow):
				if time[m] > time[0]+1000*i and time[m] < time[0]+1000*(i+1):
					xlist2.append(xpix[m])
					ylist2.append(ypix[m])			
		elif speed[i]>0 and speed[i]<=8:
			for m in range(totalrow):
				if time[m] > time[0]+1000*i and time[m] < time[0]+1000*(i+1):
					xlist1.append(xpix[m])
					ylist1.append(ypix[m])
		else:
			for m in range(totalrow):
				if time[m] > time[0]+1000*i and time[m] < time[0]+1000*(i+1):
					xlist0.append(xpix[m])
					ylist0.append(ypix[m])
		

	plt.plot(xlist3,ylist3,color='#FF0000')
	plt.plot(xlist2,ylist2,color='#CC6600')
	plt.plot(xlist1,ylist1,color='#006600')
	plt.plot(xlist0,ylist0,color='#6495ED')
	plt.gca().invert_yaxis()
	plt.xticks(range(136))
	plt.yticks(range(136))
	plt.savefig(fullname[0]+'/Figures/0'+strg+'.png')
	plt.clf()
	

