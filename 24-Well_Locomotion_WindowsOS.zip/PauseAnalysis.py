#This python code was written by Li Hankun & Huo Xiaojing @ 11/12/2017
import os, sys, string, math, openpyxl, shutil, csv
import numpy as np
import pandas as pd

#input file name and sample numbers
name1=sys.argv[1]
name2=sys.argv[2]

#create new diretory for pause csv files
fullname=name1.split(".")
Pause = {}

if os.path.exists(fullname[0]+'/Pause/'):
	shutil.rmtree(fullname[0]+'/Pause/')
os.makedirs(fullname[0]+'/Pause/')

for x in range(int(name2)+1):
	if x==0:
		continue
	if x<10:
		strg=str('v00'+str(x))
	if x>9:
		strg=str('v0'+str(x))
		
	df = pd.read_csv(fullname[0]+'/Velocity/'+strg+'.csv')
	velocity=df['mm/s']
	totalrow=len(df)

	i=0
	n=0
	m=0
	list1=[]
	list2=[]

	while n < totalrow-2:
		#3 continuous seconds as 1 pause
		s = velocity[n] + velocity[n+1] + velocity[n+2]
		if s<>0:
			n+=1
			continue
		else:
			i+=1
			for m in range(totalrow-2-n):
				s=s+velocity[n+2+m]
				if s<>0:
					break      		
				else:continue
			n=n+2+m
		
		#time point the fish start pausing
		list1.append(n-2-m)
		
		#the time duration fish paused
		if m<>0 and n<>totalrow-1:
			list2.append(m+2)
		else:
			list2.append(m+3)
	
	pps = pd.DataFrame(list(zip(list1,list2)),columns=['Pause point','Pause duration'])
	pps.to_csv(fullname[0]+'/Pause/p'+strg+'.csv')
	
		
	
				

	
