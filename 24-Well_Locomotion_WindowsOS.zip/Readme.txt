Readme
Done by Li Hankun @ 22/12/2017
Python v2.7.10 npTDMS v0.11.3 Pandas v0.21.1 Matplotlib v2.1.0 NumPy v1.13.3

This python package contains 5 files:
1. TdmsExtractorToCSV.py:
This file can extract useful information from .tdms file and put in new .csv files.
When run this file, file name and sample numbers need to be provided as augments by user.
For example: TdmsExtractorToCSV.py filename sample_numbers
.csv files will be created and stored under a new folder named "(filename)/RawData/".

2. VelocityPerSec.py:
This file can calculate the velocity at each seconds during recording. 
When run this file, file name and sample numbers need to be provided as augments by user.
For example: VelocityPerSec.py filename sample_numbers
.csv files will be created and stored under a new folder named "(filename)/Velocity/"

3. SpeedStage.py:
This file can analyse the velocity at each seconds and divide the velocity into three different stages, 
and calculate the totaldistance each fish travelled during recording. 
When run this file, file name and sample numbers need to be provided as augments by user.
For example: SpeedStage.py filename sample_numbers
.csv files will be created and stored in the same folder "(filename)/Velocity/" and named V_category and Totaldistance

4. PauseAnalysis.py:
This file can analyse the pause events (3 sec without movement) in each fish.
When run this file, file name and sample numbers need to be provided as augments by user.
For example: PauseAnalysis.py filename sample_numbers
.csv files will be created and stored under a new folder named "(filename)/Pause/"

5. FigureCreator.py:
This file can create the figures for:
	1. velocity category:
		Figures for the percentages of seconds in different velocity categories of each fish
		Figure will be stored in "(filename)/Figures/" and named V_category.png
		
	2. total distance of the fish:
		Figures for the total distance each fish travelled
		Figure will be stored in "(filename)/Figures/" and named TotalDistance.png
		
	3. pause numbers and total pause time of the fish:
		Figures for the pause numbers and pause duration of each fish
		Figures will be stored in "(filename)/Figures/" and named Pausenumber.png and Pausetime.png
		
	4. the movement of each fish:
		Figures illustrating fish movement during recording
		Figures will be stored in "(filename)/Figures/" and named after each fish number as "001.png"
		
When run this file, file name and sample numbers need to be provided as augments by user.
For example: FigureCreator.py filename sample_numbers

To use this package:
1. Put your tdms files in the same folder containing all the .py files.
2. Run TdmsExtractorToCSV.py first in cmd. (Windows)
3. Run VelocityPerSec.py in cmd
4. Run SpeedStage.py in cmd
5. Run PauseAnalysis.py in cmd
6. Run FigureCreator.py in cmd

Error example:
1. C:\Users\Hanku\Desktop\ASM lab project\50fps_15mMPTZ>TdmsExtractorToCSV.py LOG_2017-12-21_15-29-45 24
Traceback (most recent call last):
  File "C:\Users\Hanku\Desktop\ASM lab project\50fps_15mMPTZ\TdmsExtractorToCSV.py", line 20, in <module>
    tdms_file=TdmsFile(name1)
  File "C:\Python27\lib\site-packages\nptdms\tdms.py", line 93, in __init__
    with open(file, 'rb') as f:
IOError: [Errno 13] Permission denied: 'LOG_2017-12-21_15-29-45'

It means the filename is not completed.

2. 