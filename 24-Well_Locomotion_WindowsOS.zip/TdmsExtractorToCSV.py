#This python code was done by Li Hankun @ 4/12/2017
import numpy as np
from nptdms import TdmsFile
import os, sys, string, math, openpyxl, shutil, csv
import pandas as pd

#input file name and sample numbers
name1=sys.argv[1]
name2=sys.argv[2]

fullname=name1.split(".")

#create new folder of different tdms files
#if the folder already exists, remove all subdirectories and write again
if os.path.exists(fullname[0]+'/RawData/'):
	shutil.rmtree(fullname[0]+'/RawData/')
os.makedirs(fullname[0]+'/RawData/')

#read a tdms file
tdms_file=TdmsFile(name1)
data = {}

#channel_names
xpix='cXpix0'
ypix='cYpix0'
distance='distance_mm0'


#loop for extract contents of tdms files
#create csv files for different samples
for i in range(int(name2)+1):
	if i == 0:
		continue
	if i < 10:
		strg=str('0'+str(i))
	if i>9:
		strg=str(i)
		
	#channels can be changed with different groups and different channels
	channelX_object=tdms_file.object("Tracker",xpix+strg)
	channelY_object=tdms_file.object("Tracker",ypix+strg)
	channelDistance_object=tdms_file.object("Tracker", distance+strg)
	
	channelFS_object=tdms_file.object("Tracker","FrameStamp")
	channelTS_object=tdms_file.object("Tracker", "Timestamp")
	
	data[0]=channelFS_object.data
	data[1]=channelTS_object.data
	data[2]=channelX_object.data
	data[3]=channelY_object.data
	data[4]=channelDistance_object.data
	
	#.csv files can be stored at different place and renamed
	df= pd.DataFrame(data)
	filename='0'+strg+'.csv'
	df.to_csv(fullname[0]+'/RawData/'+filename, float_format= '%.12f',header=['FrameStamp','Timestamp','Xpix','Ypix','distance'],index=False)